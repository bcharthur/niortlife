class AppUrls {
  static const String sortirNiortDeals = 'https://www.sortiraniort.fr/bons-plans/';
  static const String tnTBusApiBase  = 'https://api.tanlib.com'; // exemple; à remplacer
  static const String officeTourismeBars = 'https://www.niortmaraispoitevin.com/...'; // placeholder
}
