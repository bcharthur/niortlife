enum POICategory { bar, restaurant, bus, busStop, event, deal, discount, other }
