class BusLine {
  final String id;
  final String name;
  final String? color;
  const BusLine({required this.id, required this.name, this.color});
}
