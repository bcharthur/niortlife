class BusStop {
  final String id;
  final String name;
  final double lat, lng;

  const BusStop({required this.id, required this.name, required this.lat, required this.lng});
}
